package com.bagus.moviecatalogue.data

data class TvshowEntity(
    var tvid: String,
    var title: String,
    var desc: String,
    var releaseDate: String,
    var poster: String
)
