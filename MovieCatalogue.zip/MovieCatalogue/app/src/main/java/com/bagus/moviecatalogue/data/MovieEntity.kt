package com.bagus.moviecatalogue.data

data class MovieEntity (
    var mid: String,
    var title: String,
    var desc: String,
    var releaseDate: String,
    var poster: String
)